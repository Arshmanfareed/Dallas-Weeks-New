
<?php $__env->startSection('content'); ?>
    <section class="main_dashboard blacklist campaign_detail_sec">
        <div class="container_fluid">
            <div class="row">
                <div class="col-lg-1">
                    <?php echo $__env->make('partials/dashboard_sidebar_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-lg-11">
                    <div class="border_box">
                        <div class="camp_details">
                            <h4>Campaign Details:</h4>
                            <table class="details_table">
                                <tr>
                                    <td class="item_name">Name:</td>
                                    <td class="item_value"><?php echo e($campaign->campaign_name); ?></td>
                                </tr>
                                <tr>
                                    <td class="item_name">Type:</td>
                                    <td class="item_value"><?php echo e($campaign->campaign_type); ?></td>
                                </tr>
                                <tr>
                                    <td class="item_name">Url:</td>
                                    <td class="campaign_url"><?php echo e($campaign->campaign_url); ?></td>
                                </tr>
                                <?php if($campaign->campaign_connection): ?>
                                    <tr>
                                        <td class="item_name">Connections:</td>
                                        <?php if($campaign->campaign_connection == '1'): ?>
                                            <td class="item_value">1st degree</td>
                                        <?php elseif($campaign->campaign_connection == '2'): ?>
                                            <td class="item_value">2nd degree</td>
                                        <?php elseif($campaign->campaign_connection == '3'): ?>
                                            <td class="item_value">3rd degree</td>
                                        <?php else: ?>
                                            <td class="item_value">Others</td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                        <div class="comp_tabs">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <button class="nav-link active" id="nav-email-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-email" type="button" role="tab" aria-controls="nav-email"
                                        aria-selected="true">Email settings</button>
                                    <button class="nav-link" id="nav-linkedin-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-linkedin" type="button" role="tab"
                                        aria-controls="nav-linkedin" aria-selected="false">LinkedIn settings</button>
                                    <button class="nav-link" id="nav-global-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-global" type="button" role="tab"
                                        aria-controls="nav-global" aria-selected="false">Global settings</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-email" role="tabpanel"
                                    aria-labelledby="nav-email-tab">
                                    <?php
                                        $email_settings = App\Models\EmailSetting::where(
                                            'campaign_id',
                                            $campaign->id,
                                        )->get();
                                    ?>
                                    <?php $__currentLoopData = $email_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->setting_slug != 'email_settings_schedule_id'): ?>
                                            <div class="linked_set d-flex justify-content-between">
                                                <p> <?php echo e(str_replace('Email Settings ', '', $item->setting_name)); ?></p>
                                                <div class="switch_box"><input type="checkbox"
                                                        name="<?php echo e($item->setting_slug); ?>" class="linkedin_setting_switch"
                                                        id="<?php echo e($item->setting_slug); ?>"
                                                        <?php echo e($item->value == 'yes' ? 'checked' : ''); ?>

                                                        data-id="<?php echo e($item->id); ?>"><label
                                                        for="<?php echo e($item->setting_slug); ?>">Toggle</label>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="schedule_div">
                                                <table class="schedule_table">
                                                    <thead>
                                                        <th>Day</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Status</th>
                                                    </thead>
                                                    <?php
                                                        $schedules = App\Models\ScheduleDays::where(
                                                            'schedule_id',
                                                            $item->value,
                                                        )
                                                            ->orderBy('id')
                                                            ->get();
                                                    ?>
                                                    <?php if($schedules): ?>
                                                        <tbody>
                                                            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e(ucfirst($day->schedule_day)); ?></td>
                                                                    <td><?php echo e(date('h:i A', strtotime($day->start_time))); ?>

                                                                    </td>
                                                                    <td><?php echo e(date('h:i A', strtotime($day->end_time))); ?></td>
                                                                    <td><?php echo e($day->is_active == 1 ? 'Open' : 'Closed'); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    <?php endif; ?>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="tab-pane fade" id="nav-linkedin" role="tabpanel"
                                    aria-labelledby="nav-linkedin-tab">
                                    <?php
                                        $linkedin_settings = App\Models\LinkedinSetting::where(
                                            'campaign_id',
                                            $campaign->id,
                                        )->get();
                                    ?>
                                    <?php $__currentLoopData = $linkedin_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="linked_set d-flex justify-content-between">
                                            <p><?php echo e(str_replace('Linkedin Settings ', '', $item->setting_name)); ?></p>
                                            <div class="switch_box"><input type="checkbox" name="<?php echo e($item->setting_slug); ?>"
                                                    class="linkedin_setting_switch" id="<?php echo e($item->setting_slug); ?>"
                                                    <?php echo e($item->value == 'yes' ? 'checked' : ''); ?>

                                                    data-id="<?php echo e($item->id); ?>"><label
                                                    for="<?php echo e($item->setting_slug); ?>">Toggle</label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="tab-pane fade" id="nav-global" role="tabpanel" aria-labelledby="nav-global-tab">
                                    <?php
                                        $global_settings = App\Models\GlobalSetting::where(
                                            'campaign_id',
                                            $campaign->id,
                                        )->get();
                                    ?>
                                    <?php $__currentLoopData = $global_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->setting_slug != 'global_settings_schedule_id'): ?>
                                            <div class="linked_set d-flex justify-content-between">
                                                <p><?php echo e(str_replace('Global Settings ', '', $item->setting_name)); ?></p>
                                                <div class="switch_box"><input type="checkbox"
                                                        name="<?php echo e($item->setting_slug); ?>" class="linkedin_setting_switch"
                                                        id="<?php echo e($item->setting_slug); ?>"
                                                        <?php echo e($item->value == 'yes' ? 'checked' : ''); ?>

                                                        data-id="<?php echo e($item->id); ?>"><label
                                                        for="<?php echo e($item->setting_slug); ?>">Toggle</label>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="schedule_div">
                                                <table class="schedule_table">
                                                    <thead>
                                                        <th>Day</th>
                                                        <th>Start Time</th>
                                                        <th>End Time</th>
                                                        <th>Status</th>
                                                    </thead>
                                                    <?php
                                                        $schedules = App\Models\ScheduleDays::where(
                                                            'schedule_id',
                                                            $item->value,
                                                        )
                                                            ->orderBy('id')
                                                            ->get();
                                                    ?>
                                                    <?php if($schedules): ?>
                                                        <tbody>
                                                            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e(ucfirst($day->schedule_day)); ?></td>
                                                                    <td><?php echo e(date('h:i A', strtotime($day->start_time))); ?>

                                                                    </td>
                                                                    <td><?php echo e(date('h:i A', strtotime($day->end_time))); ?></td>
                                                                    <td><?php echo e($day->is_active == 1 ? 'Open' : 'Closed'); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    <?php endif; ?>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row camp_sequence">
                            
                            <div class="col-lg-9 drop-pad">
                                <h5>Sequence Steps</h5>
                                <div class="task-list"></div>
                            </div>
                            <div class="col-lg-3 add-elements">
                                <div class="element-tab">
                                    <button class="element-btn active" id="properties-btn"
                                        data-tab="properties">Properties</button>
                                </div>
                                <div class="properties active" id="properties"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials/dashboard_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\dallas-weeks\resources\views/campaignDetails.blade.php ENDPATH**/ ?>
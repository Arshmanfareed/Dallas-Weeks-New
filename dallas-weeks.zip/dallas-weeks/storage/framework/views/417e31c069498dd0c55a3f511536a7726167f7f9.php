<?php
    use Illuminate\Support\Str;
?>
<div class="sidebar_menu col-12  p-0 flex-shrink-1">
    <ul class="list-unstyle p-0 m-0">
        <li><a href="/accdashboard"
                class="nav_link <?php echo e(Str::contains(request()->url(), URL('accdashboard')) ? 'active' : ''); ?>"><img
                    src="<?php echo e(asset('assets/img/home.svg')); ?>" alt=""></a></li>
        <li><a href="<?php echo e(route('campaigns')); ?>"
                class="nav_link <?php echo e(Str::contains(request()->url(), URL('campaign')) ? 'active' : ''); ?>"><img
                    src="<?php echo e(asset('assets/img/speaker.svg')); ?>" alt=""></a></li>
        <li><a href="<?php echo e(route('dash-leads')); ?>"
                class="nav_link <?php echo e(Str::contains(request()->url(), URL('leads')) ? 'active' : ''); ?>"><img
                    src="<?php echo e(asset('assets/img/leads.svg')); ?>" alt=""></a></li>
        <li><a href="<?php echo e(route('dash-reports')); ?>"
                class="nav_link <?php echo e(Str::contains(request()->url(), URL('report')) ? 'active' : ''); ?>"><img
                    src="<?php echo e(asset('assets/img/stat.svg')); ?>" alt=""></a></li>
        <li><a href="<?php echo e(route('dash-messages')); ?>"
                class="nav_link <?php echo e(Str::contains(request()->url(), URL('message')) ? 'active' : ''); ?>"><img
                    src="<?php echo e(asset('assets/img/message.svg')); ?>" alt=""></a></li>
        
        <li><a href="<?php echo e(route('dash-integrations')); ?>"
                class="nav_link <?php echo e(Str::contains(request()->url(), URL('integration')) ? 'active' : ''); ?>"><img
                    src="<?php echo e(asset('assets/img/clip.svg')); ?>" alt=""></a></li>
        <li><a href="<?php echo e(route('dash-settings')); ?>"
                class="nav_link <?php echo e(Str::contains(request()->url(), URL('setting')) ? 'active' : ''); ?>"><img
                    src="<?php echo e(asset('assets/img/settings.svg')); ?>" alt=""></a></li>
        
    </ul>
    <?php
        $user = auth()->user();
    ?>
    <div class="logout">
        <?php if($user): ?>
            <a href="<?php echo e(route('logout-user')); ?>"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <img src="<?php echo e(asset('assets/img/logout.svg')); ?>" alt="">
            </a>
        <?php endif; ?>
        <form id="logout-form" action="<?php echo e(route('logout-user')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</div>
<?php /**PATH C:\wamp\www\dallas-weeks\resources\views/partials/dashboard_sidebar_menu.blade.php ENDPATH**/ ?>
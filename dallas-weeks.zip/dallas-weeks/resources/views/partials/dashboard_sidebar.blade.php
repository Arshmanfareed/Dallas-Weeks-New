<div class="col-lg-4">
    <div class="sidebar dashboard">
        <div class="cont">
            <h3>Choose the
                account you wish
                to manage.</h3>
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem</p>
            <img src="{{ asset('assets/img/small_img.png') }}" alt="">
        </div>
        <div class="play_btn">
            <a href="#"><i class="fa-solid fa-play"></i>Watch the explainer video</a>
        </div>
    </div>
</div>

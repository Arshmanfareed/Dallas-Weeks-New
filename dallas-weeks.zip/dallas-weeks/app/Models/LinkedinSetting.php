<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LinkedinSetting extends Model
{
    use HasFactory;
    protected $table = 'linkedin_setting';
    protected $guarded = '';
}

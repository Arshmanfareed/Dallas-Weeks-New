<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Roles extends Controller
{
    //
}
